package com.example.loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ParameterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parameter);

        TextView textViewParameter = findViewById(R.id.textViewParameter);
        Button buttonBack = findViewById(R.id.buttonBackParam);

        // Получаем переданную фамилию
        Intent intent = getIntent();
        String surname = intent.getStringExtra("SURNAME");

        if (surname != null) {
            // Используем ресурсы для текста
            String parameterText = getString(R.string.parameter_text, surname);
            textViewParameter.setText(parameterText);
        }

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}