package com.example.loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView textViewMessage;
    private Button buttonBack, buttonToThird;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textViewMessage = findViewById(R.id.textViewMessage);
        buttonBack = findViewById(R.id.buttonBack);
        buttonToThird = findViewById(R.id.buttonToThird);

        //Проверка авторизации
        Intent intent = getIntent();
        String email = intent.getStringExtra("EMAIL");
        String password = intent.getStringExtra("PASSWORD");

        if (email != null && password != null) {
            if (email.equals("admin@admin.ru") && password.equals("123")) {
                String welcomeMessage = getString(R.string.welcome_message, email);
                textViewMessage.setText(welcomeMessage);
            } else {
                textViewMessage.setText(R.string.auth_error);
            }
        }

        //Кнопка "Назад"
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Кнопка для перехода на третий экран
        buttonToThird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                startActivity(intent);
            }
        });
    }
}